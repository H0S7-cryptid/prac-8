#ifndef PRICE
#define PRICE

#include "NEEDED_LIB.h"

class Price {
private:
	double price;
	Mtype currency;
	void doPrice(double price);
	void tryCurrency(Mtype setter);
public:
	Price();
	Price(double a, const Mtype& c);
	Price& operator=(const Price& other);
	void setPrice(double price);
	void setCurrency(Mtype mtype);
	double getAmount() const;
	Mtype getCurrency() const;
	Price convertTo(const Mtype& newCurrency, double exchangeRate) const;
	void print() const;
};

#endif 